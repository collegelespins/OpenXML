I hope to soon add some more documentation on how to use this library, but for now, this code snippet is all I have available. The library works a lot like described on my blog [here](http://chris.59north.com/post/OpenXML-2b-Silverlight-using-a-little-library.aspx) and [here](http://chris.59north.com/post/OpenXML-2b-Silverlight.aspx). It has however been reworked from that initial version to make it more flexible. So some changes have been made...

{{
private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
{
    SaveFileDialog dlg = new SaveFileDialog();    
    dlg.Filter = "Word Document (.docx)|**.docx|Zip Files (.zip)|**.zip";  
    dlg.DefaultExt = ".docx";    
    if (dlg.ShowDialog() == true)    
    {
        WordDocument doc = new WordDocument(); 
        doc.ApplicationName = "MyApplication"; 
        doc.Creator = "Chris Klug"; 
        doc.Company = "Intergen";

        FontReference comicSans;
        FontReference aharoni;
        AddFonts(doc, out comicSans, out aharoni);
        Style style = AddStyle(doc, "TitleStyle", "Title Style", aharoni);

        Run run = doc.Document.CreateElement<Run>(); 
        Text t = doc.Document.CreateElement<Text>(); 
        t.Content = "Title"; 
        run.Content.Add(t); 
        run.Properties.Style = style; 
        doc.Document.Sections[0](0)(0).Paragraphs[0](0)(0).Runs.Add(run);

        Paragraph p = doc.Document.CreateElement<Paragraph>(); run = doc.Document.CreateElement<Run>();
        run.Properties.Font.HighAnsi = comicSans;
        run.Properties.Font.ComplexScript = comicSans;
        run.Properties.Font.ASCII = comicSans;
        run.Properties.Font.EastAsia = comicSans;

        t = doc.Document.CreateElement<Text>();
        t.Content = "My Text";
        run.Content.Add(t);

        run.Content.Add(doc.Document.CreateElement<Break>());

        t = doc.Document.CreateElement<Text>();
        t.Content = "My Text On The Next Line";
        run.Content.Add(t);

        p.Runs.Add(run);
        doc.Document.Sections[0](0).Paragraphs.Add(p); 

        using (IStreamProvider storage = new ZipStreamProvider(dlg.OpenFile())) 
        { 
            doc.Save(storage); 
        }
    }
}

private void AddFonts(WordDocument doc, out FontReference comicSans, out FontReference aharoni)
{
    FontDefinition fontDefinition = doc.FontTable.CreateFontDefinition("Comic Sans MS"); 
    fontDefinition.Panose1 = "030F0702030302020204"; 
    fontDefinition.CharSet = "00"; 
    fontDefinition.Family = FontFamilyEnumeration.Script; 
    fontDefinition.Pitch = FontPitchEnumeration.Variable; 
    fontDefinition.Signature.UnicodeSignature0 = "00000287"; 
    fontDefinition.Signature.CodePageSignature0 = "0000009F";
    comicSans = doc.FontTable.AddFont(fontDefinition);

    fontDefinition = doc.FontTable.CreateFontDefinition("Aharoni");
    fontDefinition.Panose1 = "02010803020104030203"; 
    fontDefinition.CharSet = "B1"; 
    fontDefinition.Family = FontFamilyEnumeration.Auto; 
    fontDefinition.Pitch = FontPitchEnumeration.Variable; 
    fontDefinition.Signature.UnicodeSignature0 = "00000801"; 
    fontDefinition.Signature.CodePageSignature0 = "00000020";
    aharoni = doc.FontTable.AddFont(fontDefinition);
}

private Style AddStyle(WordDocument doc, string id, string name, FontReference font)
{
    CharacterStyle style = doc.Styles.AddCharacterStyle(id, name); 
    style.RunProperties.FontSize = 30; 
    style.RunProperties.IsBold = true;
    style.RunProperties.Font.ComplexScript = font;
    style.RunProperties.Font.HighAnsi = font;
    style.RunProperties.Font.ASCII = font;
    style.RunProperties.Font.EastAsia = font;
    return style;
}
}}
